import java.util.Scanner;

public class Staff {
	private String name;  //tên
	private double salary;//lương
	public double bonus;
	
	//hàm khởi tạo: Construc
	public Staff() {};
	public Staff(String name, double salary) {
		super();
		this.name = name;
		this.salary = salary;
	}
	//phương thức
	public void getBonus() {
		bonus = salary*0.2;
		System.out.println(" Tien thuong la:" + bonus);
	}
	
	public void getStaff() {
		System.out.println(name + "|" + salary );
		
	}
	
	Scanner sc = new Scanner(System.in);
	public void setStaff() {
		System.out.println("Nhap ten cua nhan vien:");
		name = sc.nextLine();
		System.out.println("Nhap luong cua nhan vien:");
		salary = sc.nextDouble();
	}
}
