
public class Main {

	public static void main(String[] args) {
		Staff nv1 = new Staff();
		ParttimeStaff nv2 = new ParttimeStaff();
		
		nv1.setStaff();
		nv2.setStaff();
		
		nv1.getStaff();
		nv1.getBonus();
		
		nv2.getStaff();
		nv2.getBonus();
	}

}
