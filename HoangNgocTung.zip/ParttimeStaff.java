
public class ParttimeStaff extends Staff{
	
	@Override
	public void getBonus() {
		System.out.println("Tien thuong la:" + 0);
	}
	@Override
	public void getStaff() {
		super.getStaff();
	}
	@Override
	public void setStaff() {
		super.setStaff();
	}

}
